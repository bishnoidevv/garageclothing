GARAGE SHOPPING BAG — IMAGE ASSETS

Put all image assets in this folder. index.html references them with relative paths.

LOGO
- garage-logo.png — GARAGE logo image (transparent PNG recommended)

SHOPPING BAG
- product-1.jpg — StretchTerry Wide Leg Pants
- product-2.jpg — SnatchRib Crossover Longsleeve Top
- product-3.jpg — Snatch Booty StretchTerry Pants
- product-4.jpg — Perfect Puff Jacket

FREQUENTLY BOUGHT TOGETHER
- recommended-1.jpg — Sleek Scoop Cami Top
- recommended-2.jpg — SnatchRib Crewneck Henley
- recommended-3.jpg — UltraFleece Wide Leg Pants

Keep the filenames unchanged. The page will show a text fallback if an image has not been uploaded yet.
